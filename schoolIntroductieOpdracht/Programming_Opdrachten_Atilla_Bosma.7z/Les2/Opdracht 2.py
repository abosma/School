score = input("Geef jouw score: ");

if int(score) >= 18:
    print("Gefeliciteerd! \n Je bent geslaagd met een score van 18!");
else:
    print("Je bent niet geslaagd, jouw score is onder de 18.");