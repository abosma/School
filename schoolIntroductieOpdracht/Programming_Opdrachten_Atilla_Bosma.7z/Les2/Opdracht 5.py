s = "Guido van Rossum heeft programmeertaal Python bedacht."

for letter in s:
    if letter == "a":
        print("a");
    if letter == "e":
        print("e");
    if letter == "i":
        print("i");
    if letter == "o":
        print("o");
    if letter == "u":
        print("u");