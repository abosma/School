uurLoon = input("Wat is jouw uurloon? ");
urenGewerkt = input("Hoeveel uren heb jij gewerkt? ");
loon = int(uurLoon) * int(urenGewerkt);

print(str(urenGewerkt) + " uur werken levert " + str(loon) + " euro op");