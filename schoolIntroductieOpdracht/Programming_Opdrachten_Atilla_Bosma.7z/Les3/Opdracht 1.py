def som(getal1,getal2,getal3):
    totaal = getal1 + getal2 + getal3
    return totaal;

print(som(4,2,3));