Lijst = [0, 5, 20, 12, 8, 10];

def som(getallenLijst):
    totaal = sum(getallenLijst);
    return totaal;

print(som(Lijst));