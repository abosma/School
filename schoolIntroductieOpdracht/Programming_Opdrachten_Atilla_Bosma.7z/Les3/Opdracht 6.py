def wijzig(lijst):
    lijst = ['a', 'b', 'c'];
    print(str(lijst));
    lijst.clear();
    lijst = ['d', 'e', 'f'];
    print(str(lijst));

lijst = [];

wijzig(lijst);