b = 7

def verdubbelB():
    global b
    b = b + b

verdubbelB()

print(b)